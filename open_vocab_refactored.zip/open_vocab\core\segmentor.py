#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
统一水质分割器 v1.0

整合多个先前版本的最佳实践:
1. RADSeg 风格的对比提示词匹配 (Contrastive Prompt Matching)
2. 两阶段分割 (水体定位 + 水质分类)
3. 颜色一致性校验 (Color Consistency Validation)
4. 多 adaptor 支持 (SigLIP2, DINOv3, SAM3)

7 类水质检测:
- 黑水 (black_water)
- 浑浊水 (turbid_water)
- 红水 (red_water)
- 绿水 (green_water)
- 乳白水 (milky_foam_water)
- 坝体渗水 (dam_seepage)
- 正常水质 (normal_water)

作者: 空中智能体团队
日期: 2026-04-05
"""

import os
import torch
import torch.nn.functional as F
import numpy as np
import cv2
from typing import Dict, List, Optional, Tuple
from dataclasses import dataclass
from pathlib import Path
import logging

from .backbone import RadioBackbone
from .classifier import SigLIP2Classifier, ColorValidator

logger = logging.getLogger(__name__)


def _odd_kernel(v: int, default: int) -> int:
    """将核大小规范为 >=3 的奇数"""
    try:
        x = max(3, int(v))
        return x + 1 if x % 2 == 0 else x
    except Exception:
        return default


@dataclass
class SegmentResult:
    """分割结果"""
    class_name: str
    class_name_cn: str
    mask: np.ndarray        # [H, W] bool
    area_ratio: float       # 占图像面积比
    score: float            # 置信度
    water_iou: float = 0.0  # 水体提取 IoU (两阶段模式)
    color_ok: bool = True   # 颜色验证是否通过
    color_score: float = 0.0  # 颜色验证得分
    patch_scores: Optional[np.ndarray] = None


class WaterQualitySegmentor:
    """
    统一水质分割器 v1.0

    核心流程:
      1. RADIO 提取 patch 特征
      2. SigLIP2 adaptor 对齐到语言空间
      3. 与文本嵌入计算相似度 (对比提示词)
      4. 颜色一致性校验
      5. 后处理 (形态学 + 水体约束)

    支持两种模式:
      - 单阶段: 直接使用 RADIO 特征进行分割
      - 两阶段: 先提取水体区域, 再进行水质分类
    """

    # 7 类水质颜色映射 (BGR)
    CLASS_COLORS = {
        "black_water": (0, 0, 180),           # 深蓝色 - 黑水
        "turbid_water": (42, 100, 170),       # 茶色 - 浑浊水
        "red_water": (0, 0, 255),             # 红色 - 红水
        "green_water": (0, 200, 0),           # 绿色 - 绿水/藻类
        "milky_foam_water": (200, 200, 200),  # 浅灰色 - 乳白水/泡沫水
        "dam_seepage": (100, 100, 100),       # 深灰色 - 坝体渗水
        "normal_water": (200, 200, 100),      # 淡黄色 - 正常水质
    }

    def __init__(
        self,
        checkpoint_path: Optional[str] = None,
        radio_code_dir: Optional[str] = None,
        siglip2_dir: Optional[str] = None,
        device: str = "cuda",
        input_size: int = 896,
        config: Optional[Dict] = None,
        mode: str = "single_stage",  # "single_stage" or "two_stage"
    ):
        """
        Args:
            checkpoint_path: C-RADIOv4 checkpoint 路径 (.pth.tar)
            radio_code_dir: NVlabs/RADIO 代码目录
            siglip2_dir: SigLIP2 模型目录
            device: 推理设备
            input_size: 输入尺寸
            config: 配置字典
            mode: 分割模式 ("single_stage" 或 "two_stage")
        """
        self.device = device
        self.input_size = input_size
        self.config = config or {}
        self.mode = mode

        # 加载 RADIO backbone
        self.backbone = RadioBackbone(
            checkpoint_path=checkpoint_path,
            radio_code_dir=radio_code_dir,
            siglip2_dir=siglip2_dir,
            device=device,
        )

        # 初始化分类器
        self.text_classifier = SigLIP2Classifier(
            backbone=self.backbone,
            temperature=self._get_prompt_temperature(),
            negative_weight=self._get_negative_weight(),
        )

        # 初始化颜色校验器
        self.color_validator = ColorValidator()

        # 加载推理参数
        self._load_inference_config()

        print(f"统一水质分割器初始化完成:")
        print(f"  模式: {mode}")
        print(f"  设备: {device}")
        print(f"  输入尺寸: {input_size}")
        print(f"  类别数: {len(self.CLASS_COLORS)}")

    def _load_inference_config(self):
        """加载推理配置参数"""
        radio_cfg = self.config.get("cloud", {}).get("radio", {})
        infer_cfg = radio_cfg.get("inference", {})

        # 基础参数
        self.threshold = infer_cfg.get("threshold", 0.30)
        self.min_area = infer_cfg.get("min_area", 0.005)
        self.image_gate = infer_cfg.get("image_gate", 0.08)
        self.class_thresholds = infer_cfg.get("class_thresholds", {}) or {}

        # 后处理参数
        post_cfg = infer_cfg.get("postprocess", {})
        self.post_erode_kernel = post_cfg.get("erode_kernel", 2)
        self.post_open_kernel = post_cfg.get("open_kernel", 2)
        self.post_max_components = post_cfg.get("max_components", 3)
        self.post_min_component_pixels = post_cfg.get("min_component_pixels", 50)

        # 水体识别参数
        water_cfg = infer_cfg.get("water", {})
        self.water_min_ratio = water_cfg.get("min_ratio", 0.05)
        self.water_erode_kernel = water_cfg.get("erode_kernel", 7)

        # 正常标签输出
        self.emit_normal_label = infer_cfg.get("emit_normal_label", True)
        self.normal_label_min_prob = infer_cfg.get("normal_label_min_prob", 0.45)
        self.normal_label_max_anomaly_prob = infer_cfg.get("normal_label_max_anomaly_prob", 0.35)

        # Patch 分类参数
        patch_cfg = infer_cfg.get("patch", {})
        self.num_patches = patch_cfg.get("num_patches", 64)
        self.min_overlap_threshold = patch_cfg.get("min_overlap_threshold", 0.50)
        self.patch_selection_strategy = patch_cfg.get("patch_selection_strategy", "top_k")
        self.top_k_patches = patch_cfg.get("top_k_patches", 10)
        self.overlap_weight = patch_cfg.get("overlap_weight", 1.5)

        # 颜色校验参数
        color_cfg = infer_cfg.get("color", {})
        self.color_max_dist = color_cfg.get("max_dist", 100)
        self.color_strict_prob = color_cfg.get("strict_prob", 0.65)
        self.color_enable_per_class = color_cfg.get("enable_per_class", True)
        self.color_fusion_alpha = float(color_cfg.get("fusion_alpha", 0.20))

    def _get_prompt_temperature(self) -> float:
        """获取提示词温度"""
        radio_cfg = self.config.get("cloud", {}).get("radio", {})
        return radio_cfg.get("inference", {}).get("prompt", {}).get("temperature", 6.0)

    def _get_negative_weight(self) -> float:
        """获取负提示词权重"""
        radio_cfg = self.config.get("cloud", {}).get("radio", {})
        return radio_cfg.get("inference", {}).get("prompt", {}).get("negative_weight", 0.35)

    def get_classes_config(self) -> Dict[str, dict]:
        """获取类别配置"""
        radio_cfg = self.config.get("cloud", {}).get("radio", {})
        return radio_cfg.get("classes", {})

    # ─────────────────────────────────────────────────────────────────────
    # 核心分割方法
    # ─────────────────────────────────────────────────────────────────────

    def segment(
        self,
        image: np.ndarray,
        classes_config: Optional[Dict[str, dict]] = None,
        prompts_config: Optional[Dict[str, dict]] = None,
        class_thresholds: Optional[Dict[str, float]] = None,
        threshold: Optional[float] = None,
        min_area: Optional[float] = None,
    ) -> Dict[str, SegmentResult]:
        """
        水质异常分割

        Args:
            image: BGR 图像 [H, W, 3]
            classes_config: 类别配置 (可选, 默认使用配置文件)
            prompts_config: 提示词配置
            threshold: 百分位阈值
            min_area: 最小面积占比

        Returns:
            {class_name: SegmentResult}
        """
        classes_config = classes_config or self.get_classes_config()
        threshold = threshold if threshold is not None else self.threshold
        min_area = min_area if min_area is not None else self.min_area
        class_thresholds = class_thresholds or self.class_thresholds

        orig_h, orig_w = image.shape[:2]

        # 获取请求的异常类别 (排除背景类)
        requested_classes = [
            k for k, v in classes_config.items()
            if not v.get("is_background", False)
        ]

        # ━━━ 第 1 步: 图像级分类 ━━━
        class_probs = self.text_classifier.classify_image(
            image, classes_config, prompts_config
        )

        # 图像级门控
        img_anomaly_prob = max(class_probs.get(c, 0.0) for c in requested_classes)
        low_image_conf = img_anomaly_prob < self.image_gate

        # ━━━ 第 2 步: Patch 级相似度计算 ━━━
        class_heatmaps = self.text_classifier.compute_patch_similarity(
            image, classes_config, prompts_config, self.input_size
        )

        # 应用颜色软融合
        class_heatmaps = self._apply_color_soft_fusion(
            image, class_heatmaps, classes_config
        )

        if not class_heatmaps:
            return self._maybe_emit_normal_label(
                class_probs, requested_classes, classes_config, orig_h, orig_w
            )

        # ━━━ 第 3 步: 构建异常热图 ━━━
        anomaly_heatmap = np.zeros((orig_h, orig_w), dtype=np.float32)
        best_class_map = np.zeros((orig_h, orig_w), dtype=np.int32)
        class_list = list(requested_classes)
        class_to_idx = {c: i for i, c in enumerate(class_list)}

        for cls_name in requested_classes:
            if cls_name not in class_heatmaps:
                continue
            heatmap = class_heatmaps[cls_name]

            cls_cfg = classes_config.get(cls_name, {})
            cls_thr = threshold
            if class_thresholds and cls_name in class_thresholds:
                cls_thr = float(class_thresholds[cls_name])
            elif "min_prob" in cls_cfg:
                cls_thr = float(cls_cfg.get("min_prob", threshold))
            heatmap = np.where(heatmap >= cls_thr, heatmap, 0.0)

            # 更新热图 (取最大值)
            better_mask = heatmap > anomaly_heatmap
            anomaly_heatmap = np.where(better_mask, heatmap, anomaly_heatmap)
            best_class_map = np.where(better_mask, class_to_idx[cls_name], best_class_map)

        # ━━━ 第 4 步: 识别水体区域 ━━━
        water_mask = self._identify_water_region(class_heatmaps, orig_h, orig_w)

        water_ratio = water_mask.sum() / water_mask.size
        if water_ratio < self.water_min_ratio:
            return self._maybe_emit_normal_label(
                class_probs, requested_classes, classes_config, orig_h, orig_w
            )

        # ━━━ 第 5 步: 阈值分割异常区域 ━━━
        anomaly_mask = anomaly_heatmap > 0
        anomaly_mask = anomaly_mask & water_mask

        if not anomaly_mask.any():
            return self._maybe_emit_normal_label(
                class_probs, requested_classes, classes_config, orig_h, orig_w
            )

        # ━━━ 第 6 步: 后处理 ━━━
        anomaly_mask = self._postprocess_mask(anomaly_mask, anomaly_heatmap)

        area = anomaly_mask.sum() / anomaly_mask.size
        if area < min_area:
            return self._maybe_emit_normal_label(
                class_probs, requested_classes, classes_config, orig_h, orig_w
            )

        # ━━━ 第 7 步: 确定标签 + 颜色校验 ━━━
        masked_class_map = best_class_map[anomaly_mask]
        if masked_class_map.size > 0:
            valid_mask = masked_class_map >= 0
            if valid_mask.any():
                valid_classes = masked_class_map[valid_mask]
                class_counts = np.bincount(valid_classes, minlength=len(class_list))
                best_idx = np.argmax(class_counts)
                best_anomaly_class = class_list[best_idx] if class_counts[best_idx] > 0 else None
            else:
                best_anomaly_class = None
        else:
            best_anomaly_class = None

        if best_anomaly_class is None:
            # 使用图像级分类结果
            for cls_name in requested_classes:
                if class_probs.get(cls_name, 0) > class_probs.get("normal_water", 0):
                    best_anomaly_class = cls_name
                    break

        if best_anomaly_class is None:
            if low_image_conf:
                return {}
            return self._maybe_emit_normal_label(
                class_probs, requested_classes, classes_config, orig_h, orig_w
            )

        # 颜色一致性校验
        region_bgr = self._get_region_bgr(image, anomaly_mask)
        color_ok, adjusted_score = self.color_validator.validate_color_consistency(
            best_anomaly_class,
            float(anomaly_heatmap[anomaly_mask].mean()),
            region_bgr,
            classes_config,
            self.color_max_dist,
        )

        # 计算置信度
        best_score = adjusted_score if not color_ok else float(anomaly_heatmap[anomaly_mask].mean())

        cfg = classes_config.get(best_anomaly_class, {})
        zh_name = cfg.get("zh", best_anomaly_class)

        return {
            best_anomaly_class: SegmentResult(
                class_name=best_anomaly_class,
                class_name_cn=zh_name,
                mask=anomaly_mask,
                area_ratio=float(area),
                score=float(best_score),
                water_iou=float(water_ratio),
                color_ok=color_ok,
                color_score=adjusted_score,
                patch_scores=anomaly_heatmap,
            )
        }

    # ─────────────────────────────────────────────────────────────────────
    # 辅助方法
    # ─────────────────────────────────────────────────────────────────────

    def _identify_water_region(
        self,
        class_heatmaps: Dict[str, np.ndarray],
        orig_h: int,
        orig_w: int,
    ) -> np.ndarray:
        """识别可信水体区域"""
        trusted_water = np.zeros((orig_h, orig_w), dtype=bool)

        # 从 normal_water 热图构建
        if "normal_water" in class_heatmaps:
            normal_heatmap = class_heatmaps["normal_water"]
            trusted_water = normal_heatmap > 0.3

        trusted_ratio = trusted_water.sum() / trusted_water.size

        # 如果没有正常水区域, 使用底部启发式
        if trusted_ratio < self.water_min_ratio:
            y_cutoff = int(orig_h * 0.25)
            trusted_water = np.zeros((orig_h, orig_w), dtype=bool)
            trusted_water[y_cutoff:, :] = True

        # 水体边界收缩
        kernel_size = _odd_kernel(self.water_erode_kernel, 7)
        kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (kernel_size, kernel_size))
        water_eroded = cv2.erode(trusted_water.astype(np.uint8), kernel).astype(bool)

        # 保留最大连通域
        if water_eroded.any():
            num_labels, labels, stats, _ = cv2.connectedComponentsWithStats(
                water_eroded.astype(np.uint8), connectivity=8
            )
            if num_labels > 1:
                areas = stats[1:, cv2.CC_STAT_AREA]
                largest = int(np.argmax(areas)) + 1
                water_eroded = labels == largest

        return water_eroded

    def _apply_color_soft_fusion(
        self,
        image: np.ndarray,
        class_heatmaps: Dict[str, np.ndarray],
        classes_config: Dict[str, dict],
    ) -> Dict[str, np.ndarray]:
        """颜色先验软融合"""
        if self.color_fusion_alpha <= 0:
            return class_heatmaps

        fused = {}
        for cls_name, heatmap in class_heatmaps.items():
            cfg = classes_config.get(cls_name, {})
            if not cfg.get("use_color_check", False):
                fused[cls_name] = heatmap
                continue

            color_hint = cfg.get("color_hint")
            if color_hint is None or len(color_hint) != 3:
                fused[cls_name] = heatmap
                continue

            color_sim = self._build_color_similarity_map(image, color_hint)
            fused_map = (1.0 - self.color_fusion_alpha) * heatmap + self.color_fusion_alpha * (heatmap * color_sim)
            fused[cls_name] = fused_map.astype(np.float32)

        return fused

    def _build_color_similarity_map(
        self,
        image: np.ndarray,
        color_hint: List[int],
    ) -> np.ndarray:
        """构建像素级颜色相似度图"""
        hint = np.asarray(color_hint, dtype=np.float32).reshape(1, 1, 3)
        img = image.astype(np.float32)
        dist = np.linalg.norm(img - hint, axis=2)
        sigma = max(25.0, float(self.color_max_dist) * 0.8)
        sim = np.exp(-0.5 * (dist / sigma) ** 2)
        return sim.astype(np.float32)

    def _postprocess_mask(
        self,
        mask: np.ndarray,
        conf_map: np.ndarray,
    ) -> np.ndarray:
        """后处理: 形态学操作 + 保留高分连通域"""
        # 腐蚀
        erode_k = _odd_kernel(self.post_erode_kernel, 2)
        kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (erode_k, erode_k))
        mask = cv2.erode(mask.astype(np.uint8), kernel).astype(bool)

        if not mask.any():
            return mask

        # 开运算
        open_k = _odd_kernel(self.post_open_kernel, 2)
        kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (open_k, open_k))
        mask = cv2.morphologyEx(mask.astype(np.uint8), cv2.MORPH_OPEN, kernel).astype(bool)

        if not mask.any():
            return mask

        # 保留高分连通域
        num_labels, labels, stats, _ = cv2.connectedComponentsWithStats(
            mask.astype(np.uint8), connectivity=8
        )

        if num_labels <= 2:
            return mask

        candidates = []
        for lid in range(1, num_labels):
            comp = labels == lid
            area_px = int(stats[lid, cv2.CC_STAT_AREA])
            if area_px < self.post_min_component_pixels:
                continue
            comp_conf = conf_map[comp]
            if comp_conf.size > 0:
                score = float(comp_conf.mean())
                candidates.append((lid, score, area_px))

        if not candidates:
            areas = stats[1:, cv2.CC_STAT_AREA]
            lid = int(np.argmax(areas)) + 1
            return labels == lid

        candidates.sort(key=lambda x: -x[1])
        top_labels = [lid for lid, _, _ in candidates[:self.post_max_components]]
        return np.isin(labels, top_labels)

    def _get_region_bgr(
        self,
        image: np.ndarray,
        mask: np.ndarray,
    ) -> Optional[np.ndarray]:
        """获取区域的平均 BGR 颜色"""
        ys, xs = np.where(mask)
        if len(ys) == 0:
            return None
        pixels = image[ys, xs].astype(np.float32)
        return pixels.mean(axis=0)

    def _maybe_emit_normal_label(
        self,
        class_probs: Dict[str, float],
        requested_classes: set,
        classes_config: Dict[str, dict],
        orig_h: int,
        orig_w: int,
    ) -> Dict[str, SegmentResult]:
        """在无异常时输出正常水体标签"""
        if not self.emit_normal_label:
            return {}

        normal_prob = class_probs.get("normal_water", 0.0)
        max_anomaly_prob = max(class_probs.get(c, 0.0) for c in requested_classes)

        if (normal_prob >= self.normal_label_min_prob and
            max_anomaly_prob <= self.normal_label_max_anomaly_prob):
            cfg = classes_config.get("normal_water", {})
            return {
                "normal_water": SegmentResult(
                    class_name="normal_water",
                    class_name_cn=cfg.get("zh", "正常水体"),
                    mask=np.zeros((orig_h, orig_w), dtype=bool),
                    area_ratio=0.0,
                    score=normal_prob,
                )
            }

        return {}

    # ─────────────────────────────────────────────────────────────────────
    # 可视化
    # ─────────────────────────────────────────────────────────────────────

    def visualize(
        self,
        image: np.ndarray,
        segments: Dict[str, SegmentResult],
        output_path: Optional[str] = None,
        font_path: Optional[str] = None,
    ) -> np.ndarray:
        """可视化分割结果"""
        from PIL import Image, ImageDraw, ImageFont

        vis = image.copy()
        h, w = image.shape[:2]

        if font_path is None:
            font_path = self._find_chinese_font()
        try:
            font = ImageFont.truetype(font_path, 24)
            font_small = ImageFont.truetype(font_path, 18)
        except Exception:
            font = ImageFont.load_default()
            font_small = font

        for name, seg in segments.items():
            color = self.CLASS_COLORS.get(name, (128, 128, 128))

            mask_uint8 = seg.mask.astype(np.uint8) * 255
            overlay = np.zeros_like(vis)
            overlay[mask_uint8 > 0] = color
            vis = cv2.addWeighted(vis, 0.6, overlay, 0.4, 0)

            contours, _ = cv2.findContours(
                mask_uint8, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE
            )
            cv2.drawContours(vis, contours, -1, color, 2)

            ys, xs = np.where(seg.mask)
            if len(ys) > 0:
                cy, cx = int(ys.mean()), int(xs.mean())
                label = f"{seg.class_name_cn} {seg.area_ratio:.1%}"
                score_label = f"conf: {seg.score:.1%}"

                vis_pil = Image.fromarray(cv2.cvtColor(vis, cv2.COLOR_BGR2RGB))
                draw = ImageDraw.Draw(vis_pil)

                bbox = draw.textbbox((0, 0), label, font=font)
                tw, th = bbox[2] - bbox[0], bbox[3] - bbox[1]
                tx = max(5, min(cx - tw // 2, w - tw - 5))
                ty = max(5, min(cy - th - 10, h - th - 30))

                draw.rectangle(
                    [tx - 4, ty - 2, tx + tw + 4, ty + th + 24],
                    fill=(0, 0, 0, 180),
                )
                draw.text((tx + 1, ty + 1), label, font=font, fill=(0, 0, 0))
                draw.text((tx, ty), label, font=font, fill=(255, 255, 255))
                draw.text((tx + 1, ty + th + 3), score_label, font=font_small, fill=(200, 200, 200))

                vis = cv2.cvtColor(np.array(vis_pil), cv2.COLOR_RGB2BGR)

        if output_path:
            cv2.imwrite(output_path, vis)

        return vis

    @staticmethod
    def _find_chinese_font() -> str:
        """查找中文字体"""
        import platform
        candidates = [
            "C:/windows/Fonts/msyh.ttc",
            "C:/windows/Fonts/simhei.ttf",
            "/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc",
            "/usr/share/fonts/truetype/noto/NotoSansCJK-Regular.ttc",
        ] if platform.system() == "Windows" else [
            "/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc",
            "/usr/share/fonts/truetype/noto/NotoSansCJK-Regular.ttc",
        ]
        for path in candidates:
            if os.path.exists(path):
                return path
        return ""


# ─────────────────────────────────────────────────────────────────────────
# 兼容性别名
# ─────────────────────────────────────────────────────────────────────────

UnifiedWaterSegmentor = WaterQualitySegmentor
